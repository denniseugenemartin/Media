from .models import Media
from django.contrib import admin

admin.site.register(Media)
